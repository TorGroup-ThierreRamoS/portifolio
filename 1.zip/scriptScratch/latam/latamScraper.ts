import puppeteer, { Browser, Page } from "puppeteer";
import fs from 'fs';
import path from 'path';

// Define TypeScript interfaces for the data structures
interface ReservationData {
  codigoReserva: string;
  sobrenome: string;
  mensagem: string;
  linkOficial: string;
  vooIda?: FlightData;
  vooVolta?: FlightData;
  bagagem?: BaggageData;
  assentoIda?: SeatData;
  assentoVolta?: SeatData;
  cartaoEmbarque?: BoardingPassData;
  erro?: string;
}

interface FlightData {
  origemDestino: string;
  data: string;
  hora: string;
  cidadePartida: string;
  aeroporto: string;
  numeroVoo: string;
  aeronave: string;
  operador: string;
  horaChegada: string;
  cidadeDestino: string;
  aeroportoDestino: string;
}

interface BaggageData {
  cidadeIdaParaDestino: string;
  // Additional baggage data properties would be defined here
}

interface SeatData {
  // Seat data properties would be defined here
}

interface BoardingPassData {
  nomePassageiro: string;
  codigoReservaConfirmado: string;
}

export async function scrapeLatamReservation(numeroCompra: string, lastName: string): Promise<ReservationData> {
  // Browser setup
  const browser: Browser = await puppeteer.launch({ 
    headless: true,
    args: [
      '--no-sandbox',
      '--disable-setuid-sandbox',
      '--disable-web-security',
      '--disable-features=IsolateOrigins,site-per-process',
      '--ignore-certificate-errors',
      '--disable-http2'
    ]
  });

  // Initialize variables
  let passengerName: string = '';
  let reservationCode: string = '';
  let page: Page | null = null;
  
  // Initialize reservationData with basic information
  let reservationData: ReservationData = {
    codigoReserva: numeroCompra,
    sobrenome: lastName,
    mensagem: "Dados básicos da reserva",
    linkOficial: `https://www.latamairlines.com/br/pt/minhas-viagens/second-detail?orderId=${numeroCompra}&lastname=${lastName}`
  };

  // Create debug directory if it doesn't exist
  const debugDir: string = path.join(process.cwd(), 'debug');
  if (!fs.existsSync(debugDir)) {
    fs.mkdirSync(debugDir);
  }

  try {
    console.log(`📝 Iniciando scraping da LATAM para reserva: 🎫 ${numeroCompra}, sobrenome: 👽 ${lastName}`);
    
    // ETAPA 1: CONFIGURAÇÃO DA PÁGINA
    page = await browser.newPage();
    await page.setUserAgent('Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36');
    await page.setExtraHTTPHeaders({
      'Accept-Language': 'pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7',
      'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
      'Accept-Encoding': 'gzip, deflate, br',
      'Connection': 'keep-alive',
      'Upgrade-Insecure-Requests': '1'
    });
    await page.setViewport({ width: 1280, height: 1080 });
    await page.setCacheEnabled(true);

    // ETAPA 2: NAVEGAÇÃO DIRETA PARA A PÁGINA DE DETALHES
    const directUrl: string = `https://www.latamairlines.com/br/pt/minhas-viagens/second-detail?orderId=${numeroCompra}&lastname=${encodeURIComponent(lastName)}`;
    console.log(`Navegando diretamente para: ${directUrl}`);
    
    try {
      await page.goto(directUrl, { waitUntil: 'domcontentloaded', timeout: 15000 });
      console.log('✅ Página carregada');
      await new Promise(resolve => setTimeout(resolve, 10000));
    } catch (error) {
      console.log(`⚠️ Timeout ao carregar página: ${(error as Error).message}`);
      console.log('Tentando continuar mesmo assim...');
    }

    // ETAPA 3: TRATAMENTO DO MODAL DE COOKIES
    console.log('🍪 Verificando e tratando modal de cookies...');
    try {
      // Código para tratar cookies (mantido como está)
      // ...
      
      // Remover banners de cookies do DOM como último recurso
      await page.evaluate(() => {
        const selectors: string[] = [
          "div.onetrust-pc-dark-filter",
          "#onetrust-banner-sdk",
          ".cookie-banner",
          "#cookiebanner",
          "[class*='cookie']",
          "[id*='cookie']",
          "[class*='gdpr']",
          "[id*='gdpr']"
        ];
        selectors.forEach(selector => {
          const elements = document.querySelectorAll(selector);
          elements.forEach(el => el.remove());
        });
      });
    } catch (e) {
      console.log('❌ Erro ao lidar com o modal de cookies:', (e as Error).message);
    }

    // Define helper functions for XPath operations
    async function clickXPath(xpath: string): Promise<boolean> {
      try {
        // Use page.evaluate with document.evaluate instead of page.$x
        return await page!.evaluate((path) => {
          try {
            const element = document.evaluate(
              path, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null
            ).singleNodeValue;
            if (element) {
              (element as HTMLElement).click();
              return true;
            }
          } catch (e) {
            console.error('Error in evaluate clickXPath:', e);
          }
          return false;
        }, xpath);
      } catch (e) {
        console.log(`Erro ao clicar no XPath ${xpath}: ${(e as Error).message}`);
        return false;
      }
    }
    
    async function getXPathText(xpath: string): Promise<string> {
      try {
        // Use page.evaluate with document.evaluate instead of page.$x
        return await page!.evaluate((path) => {
          try {
            const element = document.evaluate(
              path, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null
            ).singleNodeValue;
            return element ? (element as HTMLElement).textContent?.trim() || "" : "";
          } catch (e) {
            console.error('Error in evaluate getXPathText:', e);
          }
          return "";
        }, xpath);
      } catch (e) {
        console.log(`Erro ao obter texto do XPath ${xpath}: ${(e as Error).message}`);
        return "";
      }
    }

    // ETAPA 4: EXTRAÇÃO DE DADOS
    try {
      // Extract flight data
      const origemDestino: string = await getXPathText('//*[@id="item-0-summary-item-0"]/button/div/div/span[2]/span');
      const dataIda: string = await getXPathText('//*[@id="order-detail-trip-date-outbound"]');
      const horaIda: string = await getXPathText('//*[@id="order-detail-departure-time-outbound"]/span');
      const cidadePartida: string = await getXPathText('//*[@id="order-detail-city-origin-outbound"]');
      const aeroportoIda: string = await getXPathText('//*[@id="order-detail-iata-origin-outbound"]');
      const numeroVooIda: string = await getXPathText('//*[@id="order-detail-flight-number-outbound"]/span[1]');
      const aeronaveIda: string = await getXPathText('//*[@id="order-detail-flight-number-outbound"]/span[2]');
      const operadorIda: string = await getXPathText('//*[@id="order-detail-operator-outbound"]');
      
      // Destino Ida
      const horaChegadaIda: string = await getXPathText('//*[@id="order-detail-arrival-time-outbound"]/span');
      const cidadeDestinoIda: string = await getXPathText('//*[@id="order-detail-city-destination-outbound"]');
      const aeroportoDestinoIda: string = await getXPathText('//*[@id="order-detail-iata-destination-outbound"]');
      
      // Verificar se há voo de volta
      const temVolta: boolean = await clickXPath('//*[@id="item-1-summary-item-1"]/button');
      let dadosVolta: FlightData | Record<string, never> = {};
      
      if (temVolta) {
        // Código para extrair dados do voo de volta
        // ...
      }
      
      // Informações de bagagem
      await clickXPath('//*[@id="item"]/button');
      await new Promise(resolve => setTimeout(resolve, 5000));
      
      const cidadeIdaParaDestino: string = await getXPathText('//*[@id="item"]/button/div/div/span/span');
      // Outros dados de bagagem
      // ...
      
      // Verificar assentos
      const temAssentos: boolean = await clickXPath('//*[@id="seat-summary-item-0"]/button');
      let dadosAssentoIda: SeatData | Record<string, never> = {};
      
      if (temAssentos) {
        // Código para extrair dados de assentos
        // ...
      }
      
      // Verificar assentos de volta
      const temAssentosVolta: boolean = await clickXPath('//*[@id="seat-summary-item-1"]/button');
      let dadosAssentoVolta: SeatData | Record<string, never> = {};
      
      if (temAssentosVolta) {
        // Código para extrair dados de assentos de volta
        // ...
      }
      
      // Take final screenshot
      await page.screenshot({ path: `${debugDir}/latam-results-${numeroCompra}.png` });
      
      // Create reservation data object with all extracted information
      reservationData = {
        codigoReserva: numeroCompra,
        sobrenome: lastName,
        vooIda: {
          origemDestino: origemDestino || '',
          data: dataIda || '',
          hora: horaIda || '',
          cidadePartida: cidadePartida || '',
          aeroporto: aeroportoIda || '',
          numeroVoo: numeroVooIda || '',
          aeronave: aeronaveIda || '',
          operador: operadorIda || '',
          horaChegada: horaChegadaIda || '',
          cidadeDestino: cidadeDestinoIda || '',
          aeroportoDestino: aeroportoDestinoIda || ''
        },
        vooVolta: Object.keys(dadosVolta).length > 0 ? dadosVolta as unknown as FlightData : undefined,
        bagagem: {
          cidadeIdaParaDestino: cidadeIdaParaDestino || '',
          // Outros dados de bagagem
        },
        assentoIda: Object.keys(dadosAssentoIda).length > 0 ? dadosAssentoIda as SeatData : undefined,
        assentoVolta: Object.keys(dadosAssentoVolta).length > 0 ? dadosAssentoVolta as SeatData : undefined,
        mensagem: "Dados obtidos com sucesso",
        linkOficial: `https://www.latamairlines.com/br/pt/minhas-viagens/second-detail?orderId=${numeroCompra}&lastname=${lastName}`
      };
      
      // Try to get boarding pass information
      try {
        console.log('Localizando e clicando no botão de Cartão de embarque...');
        
        // Instead of using waitForXPath, use page.waitForFunction
        await page.waitForFunction(
          (selector) => document.evaluate(selector, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue !== null,
          { timeout: 10000 },
          '//*[@id="__next"]/section/section/section/main/section[1]/section/div/div/div[2]/a'
        );
        
        // Use our custom clickXPath function instead of page.$x
        const boardingPassButtonClicked: boolean = await clickXPath('//*[@id="__next"]/section/section/section/main/section[1]/section/div/div/div[2]/a');
        if (boardingPassButtonClicked) {
          console.log('✅ Botão de Cartão de embarque clicado com sucesso');
          
          // Replace waitForTimeout with a standard setTimeout wrapped in a Promise
          await new Promise(resolve => setTimeout(resolve, 3000));
          
          // Get passenger name and reservation code using our custom getXPathText function
          passengerName = await getXPathText('//*[@id="boardp-info-passenger-first-name"]');
          if (passengerName) {
            console.log('✅ Nome do passageiro coletado:', passengerName);
          }
          
          reservationCode = await getXPathText('//*[@id="boardp-info-scanning-area-pnr"]/strong');
          if (reservationCode) {
            console.log('✅ Código da reserva coletado:', reservationCode);
          }
          
          // Take screenshot of boarding pass
          await page.screenshot({ path: `${debugDir}/latam-boarding-pass-${numeroCompra}.png` });
          
          // Add boarding pass information to reservation data
          if (passengerName || reservationCode) {
            reservationData.cartaoEmbarque = {
              nomePassageiro: passengerName || '',
              codigoReservaConfirmado: reservationCode || ''
            };
          }
        } else {
          console.log('⚠️ Botão de Cartão de embarque não encontrado');
        }
      } catch (error) {
        console.log('⚠️ Erro ao processar cartão de embarque:', (error as Error).message);
      }
      
    } catch (error) {
      console.log('⚠️ Erro ao extrair dados da reserva:', (error as Error).message);
      // Manter os dados básicos já inicializados
    }
    
    // ETAPA 5: FINALIZAÇÃO E RETORNO DOS DADOS
    console.log('✅ Dados extraídos com sucesso');
    return reservationData;
    
  } catch (error) {
    console.error('❌ Erro durante o scraping da LATAM:', error);
    
    // Return basic data with error information
    reservationData.mensagem = "Falha ao obter dados da reserva";
    reservationData.erro = (error as Error).message;
    return reservationData;
    
  } finally {
    // ETAPA 6: LIMPEZA DE RECURSOS
    if (browser) {
      await browser.close();
      console.log('✅ Browser fechado');
    }
  }
}