import puppeteer, { Browser, Page } from "puppeteer";
import fs from 'fs';
import path from 'path';

// Define interfaces for reservation data
interface Airport {
  codigo: string;
  cidade: string;
  data: string;
  horario: string;
}

interface Flight {
  tipo: "SOMENTEIDA" | "IDAEVOLTA";
  numeroVoo: string;
  operadoPor: string;
  origem: Airport;
  destino: Airport;
  duracao: string;
}

interface Services {
  alterarAssento: string;
  comprarBagagem: string;
  contratarServicos: string;
}

interface ReservationData {
  codigoReserva: string;
  numeroCompra: string;
  sobrenome: string;
  nomePassageiro: string; // Added field for passenger name
  voos: Flight[];
  tipoViagem: "IDA_E_VOLTA" | "SOMENTE_IDA";
  servicos: Services;
  mensagem: string;
  linkOficial: string;
  screenshots: string[];
}

// Helper function to scroll through the entire page
async function autoScroll(page: Page): Promise<void> {
  await page.evaluate(async () => {
    await new Promise<void>((resolve) => {
      let totalHeight = 0;
      const distance = 100;
      const timer = setInterval(() => {
        const scrollHeight = document.body.scrollHeight;
        window.scrollBy(0, distance);
        totalHeight += distance;

        if (totalHeight >= scrollHeight) {
          clearInterval(timer);
          resolve();
        }
      }, 100);
    });
  });
  
  // Wait a bit after scrolling to ensure all dynamic content is loaded
  await new Promise(resolve => setTimeout(resolve, 2000));
  
  // Scroll back to top for consistent screenshots
  await page.evaluate(() => {
    window.scrollTo(0, 0);
  });
  
  // Wait a bit after scrolling back to top
  await new Promise(resolve => setTimeout(resolve, 1000));
}

export async function scrapeGolReservation(bookingCode: string, origin: string, lastName: string): Promise<ReservationData> {
  const browser = await puppeteer.launch({ 
    headless: true,
    args: [
      '--no-sandbox',
      '--disable-setuid-sandbox',
      '--disable-web-security',
      '--disable-features=IsolateOrigins,site-per-process',
      '--ignore-certificate-errors',
      '--disable-http2'
    ]
  });

  try {
    console.log(`📝 Iniciando scraping da GOL para reserva: ${bookingCode}, origem: ${origin}, sobrenome: ${lastName}`);
    const page = await browser.newPage();
    await page.setUserAgent('Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36');
    await page.setExtraHTTPHeaders({
      'Accept-Language': 'pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7',
      'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
      'Accept-Encoding': 'gzip, deflate, br',
      'Connection': 'keep-alive',
      'Upgrade-Insecure-Requests': '1'
    });
    await page.setViewport({ width: 1280, height: 1080 });
    await page.setCacheEnabled(true);

    const url = 'https://b2c.voegol.com.br/minhas-viagens/encontrar-viagem';
    console.log(`Navegando para: ${url}`);
    await page.goto(url, { waitUntil: 'networkidle2', timeout: 210000 });
    console.log('✅ Página carregada');

    await page.evaluate(() => {
      const selectors = [
        "div.onetrust-pc-dark-filter",
        "#onetrust-banner-sdk",
        ".cookie-banner",
        "#cookiebanner",
        "[class*='cookie']",
        "[id*='cookie']",
        "[class*='gdpr']",
        "[id*='gdpr']"
      ];
      selectors.forEach(selector => {
        const elements = document.querySelectorAll(selector);
        elements.forEach(el => el.remove());
      });
      console.log('✅ Banners de cookies removidos');
    });

    await new Promise(resolve => setTimeout(resolve, 10000));
    console.log('✅ Aguardou carregamento completo');

    await page.screenshot({ path: `gol-form-${bookingCode}.png` });
    console.log('✅ Screenshot salvo');

    console.log('🔍 Procurando campos do formulário...');
    let formFilled = false;

    try {
      const pnrSelector = '#input-reservation-ticket';
      const origemSelector = '#input-departure';
      const lastNameSelector = '#input-last-name';

      await page.screenshot({ path: `gol-form-before-${bookingCode}.png` });

      const hasPnrField = await page.$(pnrSelector) !== null;
      const hasOrigemField = await page.$(origemSelector) !== null;
      const hasLastNameField = await page.$(lastNameSelector) !== null;

      if (hasPnrField && hasOrigemField && hasLastNameField) {
        console.log('✅ Campos do formulário encontrados');

        // Limpar e preencher o campo de código de reserva
        await page.click(pnrSelector);
await page.keyboard.down('Control');
await page.keyboard.press('a');
await page.keyboard.up('Control');
        await page.keyboard.press('Backspace');
        await page.type(pnrSelector, bookingCode, { delay: 150 });
        console.log('✅ Preencheu o campo de código de reserva');

// Limpar e preencher o campo de origem
await page.click(origemSelector);
await page.keyboard.down('Control');
await page.keyboard.press('a');
await page.keyboard.up('Control');
await page.keyboard.press('Backspace');
await page.type(origemSelector, origin, { delay: 150 });
console.log('✅ Preencheu o campo de origem');

// Aguardar 2 segundos
await new Promise(resolve => setTimeout(resolve, 2000));

// Clicar no campo de código de reserva novamente
await page.click(pnrSelector);

        // Limpar e preencher o campo de sobrenome
        await page.click(lastNameSelector);
await page.keyboard.down('Control');
await page.keyboard.press('a');
await page.keyboard.up('Control');
        await page.keyboard.press('Backspace');
        await page.type(lastNameSelector, lastName, { delay: 150 });
        console.log('✅ Preencheu o campo de sobrenome');

        await page.screenshot({ path: `gol-form-filled-${bookingCode}.png` });
        
        // Tentar clicar no botão Continuar
        try {
          // Primeiro, tenta encontrar o botão pelo texto
          const continueButton = await page.evaluate(() => {
            const buttons = Array.from(document.querySelectorAll('button'));
            for (const button of buttons) {
              if (button.textContent?.trim().toLowerCase().includes('continuar')) {
                return button;
              }
            }
            return null;
          });
          
          if (continueButton) {
            await page.evaluate(() => {
              const buttons = Array.from(document.querySelectorAll('button'));
              for (const button of buttons) {
                if (button.textContent?.trim().toLowerCase().includes('continuar')) {
                  button.click();
                }
              }
            });
            console.log('✅ Clicou no botão Continuar via JavaScript');
            formFilled = true;
          } else {
            // Se não encontrar pelo texto, tenta pelo seletor CSS
            await page.click('#submit-button');
            console.log('✅ Clicou no botão com ID submit-button');
            formFilled = true;
          }
          
          // Aguardar a navegação
          await new Promise(resolve => setTimeout(resolve, 15000));
        } catch (e) {
          const error = e as Error;
          console.log('⚠️ Não conseguiu clicar no botão com ID submit-button:', error.message);
          const buttonClicked = await page.evaluate(() => {
            const buttons = Array.from(document.querySelectorAll('button'));
            for (const button of buttons) {
              if (button.textContent?.trim().toLowerCase().includes('continuar')) {
                button.click();
                return true;
              }
            }
            return false;
          });

          if (buttonClicked) {
            console.log('✅ Clicou no botão Continuar via JavaScript');
            formFilled = true;
          } else {
            console.log('⚠️ Não encontrou botão com texto Continuar');
          }
        }

        if (!formFilled) {
          const submitButtonSelectors: string[] = [
            'button[type="submit"]', 
            'button:contains("Buscar")', 
            'button:contains("Consultar")',
            'button:contains("Pesquisar")',
            'button:contains("Enviar")',
            'input[type="submit"]',
            'form button',
            'button.submit',
            'button.search',
            '[aria-label*="buscar"]',
            '[aria-label*="pesquisar"]',
            '[aria-label*="consultar"]'
          ];

          for (const buttonSelector of submitButtonSelectors) {
            try {
              await page.click(buttonSelector);
              console.log(`✅ Clicou no botão usando seletor: ${buttonSelector}`);
              formFilled = true;
              break;
            } catch (e) {
              console.log(`⚠️ Não conseguiu clicar no botão com seletor: ${buttonSelector}`);
            }
          }
        }
      } else {
        console.log(`❌ Campos não encontrados: PNR (${hasPnrField}), Origem (${hasOrigemField}), LastName (${hasLastNameField})`);
      }
    } catch (error) {
      const err = error as Error;
      console.log('❌ Erro na estratégia 1:', err.message);
    }

    if (!formFilled) {
      console.log('❌ Não foi possível preencher o formulário, tentando URL direta...');
      const directUrl = `https://b2c.voegol.com.br/minhas-viagens/detalhes-da-viagem`;
      console.log(`Navegando para URL direta: ${directUrl}`);
      await page.goto(directUrl, { waitUntil: 'networkidle2', timeout: 30000 });
    }

    console.log('⏳ Aguardando carregamento dos resultados...');
    await new Promise(resolve => setTimeout(resolve, 20000));
    
    // Scroll through the entire page to ensure all content is loaded
    console.log('🔄 Rolando a página para capturar todo o conteúdo...');
    await autoScroll(page);
    console.log('✅ Página rolada completamente');
    
    // Take a screenshot of the full page
    await page.screenshot({ 
      path: `gol-results-${bookingCode}.png`,
      fullPage: true 
    });
    console.log('✅ Screenshot completo dos resultados salvo');

    const pageHtml = await page.content();
    const debugDir = path.join(process.cwd(), 'debug');
    if (!fs.existsSync(debugDir)) {
      fs.mkdirSync(debugDir);
    }
    fs.writeFileSync(path.join(debugDir, `gol-results-${bookingCode}.html`), pageHtml);
    console.log('✅ HTML da página salvo para debug');

    interface PageText {
      text: string;
      tag: string;
      id: string;
      class: string;
    }

    const pageTexts: PageText[] = await page.evaluate(() => {    
      return Array.from(document.querySelectorAll('h1, h2, h3, h4, h5, h6, p, span, div, label'))
        .map(el => ({
          text: el.textContent?.trim() || '',
          tag: el.tagName,
          id: el.id,
          class: el.className
        }))
        .filter(item => item.text.length > 0);
    });
    
    fs.writeFileSync(path.join(debugDir, `gol-texts-${bookingCode}.json`), JSON.stringify(pageTexts, null, 2));
    console.log('✅ Textos da página salvos para debug');
    
    // Using the provided XPaths
    const reservationData = await page.evaluate((bookingCode, lastName) => {
      const getXPathText = (xpath: string, defaultValue: string): string => {
        const element = document.evaluate(xpath, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
        return element ? (element.textContent?.trim() || defaultValue) : defaultValue;
      };
    
      // Define bilheteCompra
      const bilheteCompra = getXPathText('//*[@id="home-header-info"]/div/div[2]/div[2]/span', '') || '';
      const passengerName = getXPathText('/html/body/app-root/gds-main/main/app-manage-travel/section[4]/app-home-traveler-details/div/div/div[1]/div[1]/div[1]/div[2]/label', '');
      
      // Voo de Ida
      const vooIda = getXPathText('//*[@id="itinenary-0"]/p', '');
      const operadoPorIda = getXPathText('//*[@id="trip-0-segment-0"]/div[1]/span', '');
      const origemIda = getXPathText('//*[@id="trip-0-segment-0-origin"]/div[2]/div/span[1]', '');
      const cidadeOrigemIda = getXPathText('//*[@id="trip-0-segment-0-origin"]/span', '');
      const dataOrigemIda = getXPathText('//*[@id="trip-0-segment-0-origin"]/div[2]/div/span[2]', '');
      const horaOrigemIda = getXPathText('//*[@id="trip-0-segment-0-origin"]/div[2]/div/span[3]', '');
    
      const destinoIda = getXPathText('//*[@id="trip-0-segment-0-destination"]/div[2]/div/span[1]', '');
      const cidadeDestinoIda = getXPathText('//*[@id="trip-0-segment-0-destination"]/div[3]/span', '');
      const dataDestinoIda = getXPathText('//*[@id="trip-0-segment-0-destination"]/div[2]/div/span[2]', '');
      const horaDestinoIda = getXPathText('//*[@id="trip-0-segment-0-destination"]/div[2]/div/span[2]', '');
      const duracaoIda = getXPathText('//*[@id="trip-0-segment-0-destination"]/div[2]/div/span[2]', '');

      // Check if there's a return flight
      const existeVooVolta = document.evaluate('//*[@id="itinenary-1"]', document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue !== null;
    
      // Return flight - only if it exists
      let vooVolta = '';
      let operadoPorVolta = '';
      let origemVolta = '';
      let cidadeOrigemVolta = '';
      let dataOrigemVolta = '';
      let horaOrigemVolta = '';
      let destinoVolta = '';
      let cidadeDestinoVolta = '';
      let dataDestinoVolta = '';
      let horaDestinoVolta = '';
      let duracaoVolta = '';
    
      if (existeVooVolta) {
        vooVolta = getXPathText('//*[@id="itinenary-1"]/p', '');
        operadoPorVolta = getXPathText('//*[@id="itinenary-1"]/p', '');
        origemVolta = getXPathText('//*[@id="trip-1-segment-0-origin"]/div[2]/div/span[1]', '');
        cidadeOrigemVolta = getXPathText('//*[@id="trip-1-segment-0-origin"]/span', '');
        dataOrigemVolta = getXPathText('//*[@id="trip-1-segment-0-origin"]/div[2]/div/span[2]', '');
        horaOrigemVolta = getXPathText('//*[@id="trip-1-segment-0-origin"]/div[2]/div/span[3]', '');
        destinoVolta = getXPathText('//*[@id="trip-1-segment-0-destination"]/div[2]/div/span[1]', '');
        cidadeDestinoVolta = getXPathText('//*[@id="trip-1-segment-0-destination"]/div[3]/span', '');
        dataDestinoVolta = getXPathText('//*[@id="trip-1-segment-0-destination"]/div[2]/div/span[2]', '');
        horaDestinoVolta = getXPathText('//*[@id="trip-1-segment-0-destination"]/div[2]/div/span[3]', '');
        duracaoVolta = getXPathText('//*[@id="trip-1-segment-0"]/div[4]/span', '');
      }

      // Service links
      const linkAlterarAssento = getXPathText('/html/body/app-root/gds-main/main/app-manage-travel/section[4]/app-home-traveler-details/div/div/div[1]/div[1]/div[1]/div[2]/label', '');
      const linkComprarBagagem = getXPathText('//*[@id="home-header-actions"]/gds-card-action[2]/div/div[2]', '');
      const linkContratarServicos = getXPathText('//*[@id="home-header-actions"]/gds-card-action[2]/div/div[2]', '');

      // Create flight array
      const voos = [
        {
          tipo: "IDA" as const,
          numeroVoo: vooIda,
          operadoPor: operadoPorIda,
          origem: {
            codigo: origemIda,
            cidade: cidadeOrigemIda,
            data: dataOrigemIda,
            horario: horaOrigemIda
          },
          destino: {
            codigo: destinoIda,
            cidade: cidadeDestinoIda,
            data: dataDestinoIda,
            horario: horaDestinoIda
          },
          duracao: duracaoIda
        }
      ];
    
      // Add return flight only if it exists
      if (existeVooVolta) {
        voos.push({
          tipo: "IDAEVOLTA" as const,  // This ensures TypeScript knows it's a literal type
          numeroVoo: vooVolta,
          operadoPor: operadoPorVolta,
          origem: {
            codigo: origemVolta,
            cidade: cidadeOrigemVolta,
            data: dataOrigemVolta,
            horario: horaOrigemVolta
          },
          destino: {
            codigo: destinoVolta,
            cidade: cidadeDestinoVolta,
            data: dataDestinoVolta,
            horario: horaDestinoVolta
          },
          duracao: duracaoVolta
        });
      }

      return {
        codigoReserva: bookingCode,
        numeroCompra: bilheteCompra,
        sobrenome: lastName,
        nomePassageiro: passengerName, // Include the passenger name in the returned object
        voos: voos,
        tipoViagem: existeVooVolta ? "IDA_E_VOLTA" as const : "SOMENTE_IDA" as const,
        servicos: {
          alterarAssento: linkAlterarAssento,
          comprarBagagem: linkComprarBagagem,
          contratarServicos: linkContratarServicos
        },
        mensagem: existeVooVolta ? "Dados obtidos com sucesso" : "Dados obtidos com sucesso. Não há passagem de volta.",
        linkOficial: `https://b2c.voegol.com.br/minhas-viagens/detalhes-da-viagem`,
        screenshots: [`gol-results-${bookingCode}.png`]
      };
    }, bookingCode, lastName);

    console.log('✅ Dados extraídos com sucesso');
    // Map the voos array to match the Flight interface tipo property
    // Map the flight types to match the Flight interface
    const mappedData = {
      ...reservationData,
      voos: reservationData.voos.map(voo => ({
        ...voo,
        tipo: voo.tipo === "IDA" ? "SOMENTEIDA" : "IDAEVOLTA"
      }))
    };
    
// Ensure the mapped data matches the ReservationData interface exactly
return {
  ...mappedData,
  voos: mappedData.voos.map(voo => ({
    ...voo,
    tipo: voo.tipo === "IDA" ? "SOMENTEIDA" : "IDAEVOLTA" as "SOMENTEIDA" | "IDAEVOLTA"
  }))
} as ReservationData;
  } catch (error) {
    const err = error as Error;
    console.error('❌ Erro durante o scraping da GOL:', error instanceof Error ? error.message : String(error));
    throw error;
  } finally {
    if (browser) {
      await browser.close();
      console.log('✅ Browser fechado');
    }
  } // Fim da função scrapeGolReservation
}
