import puppeteer, { Browser, Page } from "puppeteer";

// Define interfaces for structured data
interface Passenger {
  nome: string;
  bagagem: string;
}

interface PartidaChegada {
  aeroporto: string;
  horario: string;
}

interface FlightDetails {
  numeroVoo: string;
  partidaChegada: PartidaChegada[];
  timeCheckIn: string;
}

interface Origin {
  code: string;
  city: string;
  time: string;
}

interface Destination {
  code: string;
  city: string;
  time: string;
}

interface ReservationResponse {
  pnr: string;
  codigoReserva: string;
  destino: {
    texto: string;
    cidade: string;
  };
  datas: {
    ida: string;
    volta: string;
  };
  passageiros: Passenger[];
  voos: FlightDetails[];
  origin: Origin;
  destination: Destination;
  error?: string;
  status?: string;
  message?: string;
}

export async function scrapeAzulReservation(pnr: string, origin: string): Promise<ReservationResponse> {
  console.log(`Starting Azul scraping for PNR: ${pnr}, Origin: ${origin}`);
  const browser: Browser = await puppeteer.launch({ 
    headless: true, // Change to false to see the browser in action
    args: [
      '--no-sandbox',
      '--disable-setuid-sandbox',
      '--disable-web-security',
      '--disable-features=IsolateOrigins,site-per-process',
      '--ignore-certificate-errors',
      // Disable HTTP/2 to avoid protocol errors
      '--disable-http2'
    ]
  });
  
  try {
    const page: Page = await browser.newPage();
    
    // Set a more realistic user agent
    await page.setUserAgent('Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36');
    
    await page.setViewport({ width: 1030, height: 768 });
    await page.setCacheEnabled(false);
    
    // Add a timeout to the page navigation
    const url: string = `https://www.voeazul.com.br/br/pt/home/minhas-viagens/confirmacao?pnr=${pnr}&origin=${origin}`;
    console.log(`Navigating to URL: ${url}`);
    
    await page.goto(url, { 
      waitUntil: "networkidle2",
      timeout: 60000 // Increase timeout to 60 seconds
    });

    // Take a screenshot for debugging
    await page.screenshot({ path: `azul-reservation-${pnr}.png` });
    console.log(`Screenshot saved as azul-reservation-${pnr}.png`);

    // Check if we're on an error page
    const pageContent: string = await page.content();
    if (pageContent.includes("não encontrada") || pageContent.includes("not found")) {
      console.log("Reservation not found page detected");
      throw new Error("Reserva não encontrada. Verifique o código e a origem.");
    }

    // Try multiple selectors with increased timeout
    let passengerElementFound: boolean = false;
    try {
      await page.waitForSelector("p.info__content__name, .passenger-name, .traveler-info", { 
        timeout: 15000 
      });
      passengerElementFound = true;
      console.log("Passenger element found on page");
    } catch (error) {
      console.log("Passenger element not found, continuing anyway:", error instanceof Error ? error.message : String(error));
    }

    // Remove o bloqueio de cookies/tela preta
    await page.evaluate(() => {
      const banner = document.querySelector("div.onetrust-pc-dark-filter");
      if (banner) banner.remove();
    });

    // Pega todos os passageiros e suas bagagens
    const elementosPassageiros = await page.$$("p.info__content__name");
    const elementosBagagens = await page.$$("button.baggage__fragment span.screen-reader");

    const passageiros: Passenger[] = [];

    for (let i = 0; i < elementosPassageiros.length; i++) {
      const nomePassageiro: string = await elementosPassageiros[i].evaluate(el => el.textContent?.trim() || "");

      let bagagemText: string = "Não informado";
      if (elementosBagagens[i]) {
        bagagemText = await elementosBagagens[i].evaluate(el => el.textContent?.trim() || "");
      }

      passageiros.push({
        nome: nomePassageiro,
        bagagem: bagagemText
      });
    }

    console.log(`Found ${passageiros.length} passengers`);

    // "Sua viagem para" + destino
    let destinoTexto: string = "Informação de destino não encontrada";
    let cidadeDestino: string = "Cidade destino não encontrada";
    
    try {
      destinoTexto = await page.$eval("div.container__info__text p", el => el.textContent?.trim() || "");
      cidadeDestino = await page.$eval("div.container__info__text span.wildcard-name", el => el.textContent?.trim() || "");
      console.log(`Destination found: ${cidadeDestino}`);
    } catch (error) {
      console.log("Could not find destination information:", error instanceof Error ? error.message : String(error));
    }

    // Try to extract origin city - it might be in a different element
    // First, try to get it from the flight details
    let cidadeOrigem: string = origin; // Default to the airport code if we can't find the city name

    // Try to find origin city in the page content
    try {
      // Look for elements that might contain the origin city
      const originElements = await page.$$("div.flight-card__airport-name, div.flight-info__origin, span.origin-city");
      
      if (originElements.length > 0) {
        cidadeOrigem = await originElements[0].evaluate(el => el.textContent?.trim() || "");
        console.log(`Origin city found: ${cidadeOrigem}`);
      } else {
        // Try an alternative approach - look for airport codes and find the one matching our origin
        const airportElements = await page.$$("div.flight-card__airport-code, span.airport-code");
        
        for (let i = 0; i < airportElements.length; i++) {
          const code = await airportElements[i].evaluate(el => el.textContent?.trim() || "");
          if (code === origin) {
            // If we found our origin code, the city name might be nearby
            const parentElement = await airportElements[i].evaluateHandle(el => el.parentElement);
            const cityElement = await (parentElement as any).$(":scope > .city-name, :scope > .airport-name");
            
            if (cityElement) {
              cidadeOrigem = await cityElement.evaluate((el: Element) => el.textContent?.trim() || "");
              console.log(`Origin city found via airport code: ${cidadeOrigem}`);
              break;
            }
          }
        }
      }
    } catch (error) {
      console.log("Could not extract origin city:", error instanceof Error ? error.message : String(error));
    }

    // Coletar todas as datas (ida e volta)
    const datasElementos = await page.$$("time.container__info__period__date");

    let dataIda: string = "Não encontrado";
    let dataVolta: string = "Não encontrado";

    if (datasElementos.length > 0) {
      dataIda = await datasElementos[0].evaluate(el => el.textContent?.trim() || "");
      console.log(`Departure date: ${dataIda}`);
    }
    if (datasElementos.length > 1) {
      dataVolta = await datasElementos[1].evaluate(el => el.textContent?.trim() || "");
      console.log(`Return date: ${dataVolta}`);
    }

    // Código da reserva
    let codigoReserva: string = pnr;
    try {
      codigoReserva = await page.$eval("strong.container__reservation__text__code", el => el.textContent?.trim() || "");
      console.log(`Reservation code found: ${codigoReserva}`);
    } catch (error) {
      console.log("Could not find reservation code element, using provided PNR");
    }

    const todosVoos: FlightDetails[] = [];

    // Repetir enquanto houver botões "Detalhes do voo"
    let index: number = 0;

    while (true) {
      await new Promise(resolve => setTimeout(resolve, 1000));

      const botoesDetalhes = await page.$$("button[class*='css-od3x4h'], button[class*='css-1lxzddf']");

      if (index >= botoesDetalhes.length) {
        break;
      }

      console.log(`Processing flight ${index + 1} of ${botoesDetalhes.length}`);
      const botao = botoesDetalhes[index];

      await botao.click();
      console.log("Clicked on flight details button");

      await new Promise(resolve => setTimeout(resolve, 1000));

      // Capturar o container do cartão que foi expandido (após clique)
      const cartoesExpandido = await page.$$("div[class*='css-92p0jw']");

      if (cartoesExpandido.length === 0) {
        console.log("No expanded card found, skipping to next flight");
        index++;
        continue;
      }

      const cartaoAtual = cartoesExpandido[cartoesExpandido.length - 1];

      const conexaoVooElemento = await cartaoAtual.$("span.connections-and-flight-number");

      if (!conexaoVooElemento) {
        console.log("No flight number element found, skipping to next flight");
        index++;
        continue;
      }

      const conexaoVoo: string = await conexaoVooElemento.evaluate(el => el.textContent?.trim() || "");
      console.log(`Flight number: ${conexaoVoo}`);

      const infosPartida: PartidaChegada[] = await cartaoAtual.$$eval("div.boarding-info span", spans =>
        spans.map(span => {
          const textParts = Array.from(span.childNodes)
            .map(node => node.textContent?.trim() || "")
            .filter(text => text);

          const aeroporto = textParts[0] || "N/A";
          const horario = span.querySelector("time")?.textContent?.trim() || "N/A";

          return { aeroporto, horario };
        })
      );

      console.log(`Found ${infosPartida.length} boarding info elements`);
      if (infosPartida.length > 0) {
        console.log(`From: ${infosPartida[0].aeroporto} at ${infosPartida[0].horario}`);
      }
      if (infosPartida.length > 1) {
        console.log(`To: ${infosPartida[1].aeroporto} at ${infosPartida[1].horario}`);
      }

      // CHECK-IN (dentro do cartão expandido)
      let checkinText: string = "Não informado";
      try {
        checkinText = await cartaoAtual.$eval("div.button__text", el => el.textContent?.trim() || "");
        console.log(`Check-in info: ${checkinText}`);
      } catch (error) {
        console.log("Could not find check-in information");
      }

      todosVoos.push({
        numeroVoo: conexaoVoo,
        partidaChegada: infosPartida,
        timeCheckIn: checkinText,
      });

      // Fecha o detalhe
      const botaoFechar = await cartaoAtual.$("button[class*='css-od3x4h']");
      if (botaoFechar) {
        await botaoFechar.click();
        console.log("Closed flight details");
      }

      await new Promise(resolve => setTimeout(resolve, 1000));

      index++;
    }

    console.log(`Found ${todosVoos.length} flights total`);

    // When returning the final response
    const response: ReservationResponse = {
      pnr: codigoReserva,
      codigoReserva: codigoReserva,
      destino: {
        texto: destinoTexto,
        cidade: cidadeDestino
      },
      datas: {
        ida: dataIda,
        volta: dataVolta
      },
      passageiros: passageiros,
      voos: todosVoos,
      origin: {
        code: origin,
        city: cidadeOrigem,
        time: todosVoos.length > 0 && todosVoos[0].partidaChegada && todosVoos[0].partidaChegada.length > 0 
          ? todosVoos[0].partidaChegada[0].horario 
          : "Não disponível"
      },
      destination: {
        code: todosVoos.length > 0 && todosVoos[0].partidaChegada && todosVoos[0].partidaChegada.length > 1 
          ? todosVoos[0].partidaChegada[1].aeroporto.split(' ')[0] 
          : "Não disponível",
        city: cidadeDestino,
        time: todosVoos.length > 0 && todosVoos[0].partidaChegada && todosVoos[0].partidaChegada.length > 1 
          ? todosVoos[0].partidaChegada[1].horario 
          : "Não disponível"
      }
    };

    console.log("Scraping completed successfully");
    return response;
    
  } catch (error) {
    console.error("Error during Azul scraping:", error);
    
    // Return a fallback response with a link to the official site
    return {
      pnr: pnr,
      codigoReserva: pnr,
      destino: {
        texto: "Informação não disponível",
        cidade: "Não disponível"
      },
      datas: {
        ida: "Não disponível",
        volta: "Não disponível"
      },
      passageiros: [{
        nome: "Não disponível",
        bagagem: "Não disponível"
      }],
      voos: [],
      origin: {
        code: origin,
        city: "Não disponível",
        time: "Não disponível"
      },
      destination: {
        code: "Não disponível",
        city: "Não disponível",
        time: "Não disponível"
      },
      error: error instanceof Error ? error.message : String(error),
      status: "Erro",
      message: "Não foi possível obter os detalhes da reserva. Verifique o código e a origem ou tente novamente mais tarde."
    };
  } finally {
    // Close the browser to prevent memory leaks
    if (browser) {
      await browser.close();
      console.log("Browser closed");
    }
  }
}