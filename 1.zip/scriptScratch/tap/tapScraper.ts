import puppeteer, { Browser, Page } from "puppeteer";
import fs from 'fs';
import path from 'path';

// Define TypeScript interfaces for the data structures
interface ReservationData {
  codigoReserva: string;
  sobrenome: string;
  mensagem: string;
  linkOficial: string;
  vooIda?: FlightData;
  vooVolta?: FlightData;
  bagagem?: BaggageData;
  assentoIda?: SeatData;
  assentoVolta?: SeatData;
  cartaoEmbarque?: BoardingPassData;
  erro?: string;
}

interface FlightData {
  origemDestino: string;
  data: string;
  hora: string;
  cidadePartida: string;
  aeroporto: string;
  numeroVoo: string;
  aeronave: string;
  operador: string;
  horaChegada: string;
  cidadeDestino: string;
  aeroportoDestino: string;
}

interface BaggageData {
  cidadeIdaParaDestino: string;
  // Additional baggage data properties would be defined here
}

interface SeatData {
  // Seat data properties would be defined here
}

interface BoardingPassData {
  nomePassageiro: string;
  codigoReservaConfirmado: string;
}
